---
title: "ETL logos, icons and graphics"
weight: 10
---

You are given permission to ETL logos, icons and graphics in your blogs and publications.

**Conditions of use**  
- Do not add a drop shadow.
- Do not adjust any part of the graphic.
- Do not change the colours.
- Do not change the aspect ratio.
- Do not use the graphic to promote anything other than the ETL, unless you are informing the reader that the ETL is a major component of the work.
