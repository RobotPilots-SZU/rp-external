---
title: "timer"
---

{{< callout type="info">}}
  Header: `timer.h`  
{{< /callout >}}


Contains definitions common to timers.

## timer
```cpp
struct timer
{
  // Timer modes.
  struct mode
  {
    enum
    {
      SINGLE_SHOT = false,
      REPEATING   = true
    };

    typedef bool type;
  };

  // Timer start status.
  struct start
  {
    enum
    {
      DELAYED   = false,
      IMMEDIATE = true
    };

    typedef bool type;
  };

  // Timer id.
  struct id
  {
    enum
    {
      NO_TIMER = 255
    };

    typedef uint_least8_t type;
  };

  // Timer state.
  struct state
  {
    enum
    {
      INACTIVE = 0xFFFFFFFF
    };
  };
};
```

### mode
**Types**  
`type`
The type for timer mode.  
Defined as `bool`.

**Constants**  
`SINGLE_SHOT`  
The timer expires once and then stops.  

`REPEATING`  
The timer is restarted after every timeout.  

### start
**Types**  
`type`
The type for timer start mode.  
Defined as `bool`.

**Constants**  
`IMMEDIATE`  
- *Single Shot*  
The timer is triggered on the next tick. The normal timeout does not occur.  

- *Repeating*  
The timer is triggered on the next tick and then on subsequent timeouts.  

`DELAYED`  
The timer is triggered on the timeout.

### id
**Types**  
`type`  
The type for timer identifiers.  
Defined as `uint_least8_t`.

**Constants**  
`NO_TIMER`  
The id of an unregistered timer.

