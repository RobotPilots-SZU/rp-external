---
title: "user_type"
---

A strong typedef with constants.  

A method of declaring a strong `typedef`, like `etl::type_def`, but with a set of constants, like `enum_type`.  
Unlike enum types, a user type may be set to arbitrary values.  

**Example**  
```cpp
ETL_DECLARE_USER_TYPE(CompassDirection, int)
ETL_USER_TYPE(North, 0)
ETL_USER_TYPE(South, 180)
ETL_USER_TYPE(East,  90)
ETL_USER_TYPE(West,  270)
ETL_USER_TYPE(THIRTY_DEGREES, 30)
ETL_END_USER_TYPE(CompassDirection)

CompassDirection direction;          // Default construction.
direction = CompassDirection::North; // Assignment from an user type constant;
int value = int(direction);          // Explicit conversion to 'int'.
direction = CompassDirection(value); // Explicit conversion from 'int'.
direction = CompassDirection(3);     // Explicit conversion from an arbitrary value.
++direction;                         // Modify.
direction += CompassDirection::THIRTY_DEGREES;
direction = value;                   // **** Compilation error ****
```
