---
title: "constant"
---

{{< callout type="info">}}
  Header: `constant.h`  
  Since: `TBC`  
{{< /callout >}}

A helper class for templates that require constants and classes that declare value and value_type members.  

The class allows constants to be wrapped in a template that defines value and value_type.  
This can be particularly useful in recursively defined templates where the value is defined as either a constant or a further invocation of the template.  

**Example**  
Take the example of `etl::sqrt`.

```cpp
template <intmax_t VALUE, const intmax_t I = 1>
struct sqrt
{
  typedef typename etl::conditional<((I * I) < VALUE), 
                                    etl::sqrt<VALUE, I + 1>, 
                                    etl::constant<intmax_t, I> >::type type;

  enum value_type
  {
    value = type::value
  };
};
```

```cpp
// Stop condition.
template <const intmax_t I>
struct sqrt<I, I>
{
  enum value_type
  {
    value = I
  };
};
```

`etl::conditional` will select one of the two types based on the boolean template parameter.  
The types are expected to have a value member. This is achieved for the constant by wrapping it in `etl::constant`.
