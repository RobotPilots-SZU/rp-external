///\file

/******************************************************************************
The MIT License(MIT)

Embedded Template Library.
https://github.com/ETLCPP/etl
https://www.etlcpp.com

Copyright(c) 2019 John Wellbelove

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files(the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and / or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions :

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
******************************************************************************/

#ifndef ETL_BASIC_FORMAT_SPEC_INCLUDED
#define ETL_BASIC_FORMAT_SPEC_INCLUDED

///\ingroup string

#include "platform.h"
#include "type_traits.h"
#include "utility.h"

namespace etl
{
  namespace private_basic_format_spec
  {
    //*******************************************************
    // Structures returned by stream formatting manipulators.
    //*******************************************************
    struct base_spec
    {
      ETL_CONSTEXPR base_spec(uint_least8_t base_)
        : base(base_)
      {
      }

      const uint_least8_t base;
    };

    //*********************************
    struct width_spec
    {
      ETL_CONSTEXPR width_spec(uint_least8_t width_)
        : width(width_)
      {
      }

      const uint_least8_t width;
    };

    //*********************************
    template <typename TChar>
    struct fill_spec
    {
      ETL_CONSTEXPR fill_spec(TChar fill_)
        : fill(fill_)
      {
      }

      const TChar fill;
    };

    //*********************************
    struct precision_spec
    {
      ETL_CONSTEXPR precision_spec(uint_least8_t precision_)
        : precision(precision_)
      {
      }

      const uint_least8_t precision;
    };

    //*********************************
    struct uppercase_spec
    {
      ETL_CONSTEXPR uppercase_spec(bool upper_case_)
        : upper_case(upper_case_)
      {
      }

      const bool upper_case;
    };

    //*********************************
    struct boolalpha_spec
    {
      ETL_CONSTEXPR boolalpha_spec(bool boolalpha_)
        : boolalpha(boolalpha_)
      {
      }

      const bool boolalpha;
    };

    //*********************************
    struct showbase_spec
    {
      ETL_CONSTEXPR showbase_spec(bool show_base_)
        : show_base(show_base_)
      {
      }

      const bool show_base;
    };

    //*********************************
    struct left_spec
    {
    };

    //*********************************
    struct right_spec
    {
    };
  } // namespace private_basic_format_spec

  //***************************************************************************
  // Stream formatting manipulators.
  //***************************************************************************
  inline ETL_CONSTEXPR private_basic_format_spec::base_spec setbase(uint32_t base)
  {
    return private_basic_format_spec::base_spec(static_cast<uint_least8_t>(base));
  }

  //*********************************
  inline ETL_CONSTEXPR private_basic_format_spec::width_spec setw(uint32_t width)
  {
    return private_basic_format_spec::width_spec(static_cast<uint_least8_t>(width));
  }

  //*********************************
  template <typename TChar>
  ETL_CONSTEXPR private_basic_format_spec::fill_spec<TChar> setfill(TChar fill)
  {
    return private_basic_format_spec::fill_spec<TChar>(fill);
  }

  //*********************************
  inline ETL_CONSTEXPR private_basic_format_spec::precision_spec setprecision(uint32_t precision)
  {
    return private_basic_format_spec::precision_spec(static_cast<uint_least8_t>(precision));
  }

  //*********************************
  static ETL_CONSTANT private_basic_format_spec::base_spec bin(static_cast<uint_least8_t>(2U));

  //*********************************
  static ETL_CONSTANT private_basic_format_spec::base_spec oct(static_cast<uint_least8_t>(8U));

  //*********************************
  static ETL_CONSTANT private_basic_format_spec::base_spec dec(static_cast<uint_least8_t>(10U));

  //*********************************
  static ETL_CONSTANT private_basic_format_spec::base_spec hex(static_cast<uint_least8_t>(16U));

  //*********************************
  ETL_INLINE_VAR ETL_CONSTANT private_basic_format_spec::left_spec left = private_basic_format_spec::left_spec();

  //*********************************
  ETL_INLINE_VAR ETL_CONSTANT private_basic_format_spec::right_spec right = private_basic_format_spec::right_spec();

  //*********************************
  ETL_INLINE_VAR ETL_CONSTANT private_basic_format_spec::boolalpha_spec boolalpha(true);

  //*********************************
  ETL_INLINE_VAR ETL_CONSTANT private_basic_format_spec::boolalpha_spec noboolalpha(false);

  //*********************************
  ETL_INLINE_VAR ETL_CONSTANT private_basic_format_spec::uppercase_spec uppercase(true);

  //*********************************
  ETL_INLINE_VAR ETL_CONSTANT private_basic_format_spec::uppercase_spec nouppercase(false);

  //*********************************
  ETL_INLINE_VAR ETL_CONSTANT private_basic_format_spec::showbase_spec showbase(true);

  //*********************************
  ETL_INLINE_VAR ETL_CONSTANT private_basic_format_spec::showbase_spec noshowbase(false);

  //***************************************************************************
  /// basic_format_spec
  //***************************************************************************
  template <typename TString>
  class basic_format_spec
  {
  public:

    //***************************************************************************
    /// Default constructor.
    //***************************************************************************
    ETL_CONSTEXPR basic_format_spec() ETL_NOEXCEPT
      : base_(10U)
      , width_(0U)
      , precision_(0U)
      , upper_case_(false)
      , left_justified_(false)
      , boolalpha_(false)
      , show_base_(false)
      , fill_(typename TString::value_type(' '))
      , scientific_(false)
    {
    }

    //***************************************************************************
    /// Constructor.
    //***************************************************************************
    ETL_CONSTEXPR basic_format_spec(uint_least8_t base__, uint_least8_t width__, uint_least8_t precision__, bool upper_case__, bool left_justified__,
                                bool boolalpha__, bool show_base__, typename TString::value_type fill__, bool scientific__ = false) ETL_NOEXCEPT
      : base_(base__)
      , width_(width__)
      , precision_(precision__)
      , upper_case_(upper_case__)
      , left_justified_(left_justified__)
      , boolalpha_(boolalpha__)
      , show_base_(show_base__)
      , fill_(fill__)
      , scientific_(scientific__)
    {
    }

    //***************************************************************************
    /// Clears the format spec back to default.
    //***************************************************************************
    ETL_CONSTEXPR14 void clear() ETL_NOEXCEPT
    {
      base_           = 10U;
      width_          = 0U;
      precision_      = 0U;
      upper_case_     = false;
      left_justified_ = false;
      boolalpha_      = false;
      show_base_      = false;
      scientific_     = false;
      fill_           = typename TString::value_type(' ');
    }

    //***************************************************************************
    /// Sets the base.
    /// \return A reference to the basic_format_spec.
    //***************************************************************************
    ETL_CONSTEXPR14 basic_format_spec& base(uint32_t b) ETL_LVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      base_ = static_cast<uint_least8_t>(b);
      return *this;
    }

#if ETL_USING_CPP11
    /// @overload
    ETL_CONSTEXPR14 basic_format_spec&& base(uint32_t b) ETL_RVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      base_ = static_cast<uint_least8_t>(b);
      return etl::move(*this);
    }
#endif

    //***************************************************************************
    /// Sets the base to binary.
    /// \return A reference to the basic_format_spec.
    //***************************************************************************
    ETL_CONSTEXPR14 basic_format_spec& binary() ETL_LVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      return base(2);
    }

#if ETL_USING_CPP11
    /// @overload
    ETL_CONSTEXPR14 basic_format_spec&& binary() ETL_RVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      return etl::move(base(2));
    }
#endif

    //***************************************************************************
    /// Sets the base to octal.
    /// \return A reference to the basic_format_spec.
    //***************************************************************************
    ETL_CONSTEXPR14 basic_format_spec& octal() ETL_LVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      return base(8);
    }

#if ETL_USING_CPP11
    /// @overload
    ETL_CONSTEXPR14 basic_format_spec&& octal() ETL_RVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      return etl::move(base(8));
    }
#endif

    //***************************************************************************
    /// Sets the base to decimal.
    /// \return A reference to the basic_format_spec.
    //***************************************************************************
    ETL_CONSTEXPR14 basic_format_spec& decimal() ETL_LVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      return base(10);
    }

#if ETL_USING_CPP11
    /// @overload
    ETL_CONSTEXPR14 basic_format_spec&& decimal() ETL_RVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      return etl::move(base(10));
    }
#endif

    //***************************************************************************
    /// Sets the base to hex.
    /// \return A reference to the basic_format_spec.
    //***************************************************************************
    ETL_CONSTEXPR14 basic_format_spec& hex() ETL_LVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      return base(16);
    }

#if ETL_USING_CPP11
    /// @overload
    ETL_CONSTEXPR14 basic_format_spec&& hex() ETL_RVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      return etl::move(base(16));
    }
#endif

    //***************************************************************************
    /// Gets the base.
    //***************************************************************************
    ETL_CONSTEXPR uint32_t get_base() const ETL_NOEXCEPT
    {
      return base_;
    }

    //***************************************************************************
    /// Sets the show base flag.
    /// \return A reference to the basic_format_spec.
    //***************************************************************************
    ETL_CONSTEXPR14 basic_format_spec& show_base(bool b) ETL_LVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      show_base_ = b;
      return *this;
    }

#if ETL_USING_CPP11
    /// @overload
    ETL_CONSTEXPR14 basic_format_spec&& show_base(bool b) ETL_RVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      show_base_ = b;
      return etl::move(*this);
    }
#endif

    //***************************************************************************
    /// Gets the show base flag.
    //***************************************************************************
    ETL_CONSTEXPR bool is_show_base() const ETL_NOEXCEPT
    {
      return show_base_;
    }

    //***************************************************************************
    /// Sets the width.
    /// \return A reference to the basic_format_spec.
    //***************************************************************************
    ETL_CONSTEXPR14 basic_format_spec& width(uint32_t w) ETL_LVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      width_ = static_cast<uint_least8_t>(w);
      return *this;
    }

#if ETL_USING_CPP11
    /// @overload
    ETL_CONSTEXPR14 basic_format_spec&& width(uint32_t w) ETL_RVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      width_ = static_cast<uint_least8_t>(w);
      return etl::move(*this);
    }
#endif

    //***************************************************************************
    /// Gets the width.
    //***************************************************************************
    ETL_CONSTEXPR uint32_t get_width() const ETL_NOEXCEPT
    {
      return width_;
    }

    //***************************************************************************
    /// Sets the precision.
    /// \return A reference to the basic_format_spec.
    //***************************************************************************
    ETL_CONSTEXPR14 basic_format_spec& precision(uint32_t p) ETL_LVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      precision_ = static_cast<uint_least8_t>(p);
      return *this;
    }

#if ETL_USING_CPP11
    /// @overload
    ETL_CONSTEXPR14 basic_format_spec&& precision(uint32_t p) ETL_RVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      precision_ = static_cast<uint_least8_t>(p);
      return etl::move(*this);
    }
#endif

    //***************************************************************************
    /// Gets the precision.
    //***************************************************************************
    ETL_CONSTEXPR uint32_t get_precision() const ETL_NOEXCEPT
    {
      return precision_;
    }

    //***************************************************************************
    /// Sets the upper case flag.
    /// \return A reference to the basic_format_spec.
    //***************************************************************************
    ETL_CONSTEXPR14 basic_format_spec& upper_case(bool u) ETL_LVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      upper_case_ = u;
      return *this;
    }

#if ETL_USING_CPP11
    /// @overload
    ETL_CONSTEXPR14 basic_format_spec&& upper_case(bool u) ETL_RVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      upper_case_ = u;
      return etl::move(*this);
    }
#endif

    //***************************************************************************
    /// Gets the upper case flag.
    //***************************************************************************
    ETL_CONSTEXPR bool is_upper_case() const ETL_NOEXCEPT
    {
      return upper_case_;
    }

    //***************************************************************************
    /// Sets the fill character.
    /// \return A reference to the basic_format_spec.
    //***************************************************************************
    ETL_CONSTEXPR14 basic_format_spec& fill(typename TString::value_type c) ETL_LVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      fill_ = c;
      return *this;
    }

#if ETL_USING_CPP11
    /// @overload
    ETL_CONSTEXPR14 basic_format_spec&& fill(typename TString::value_type c) ETL_RVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      fill_ = c;
      return etl::move(*this);
    }
#endif

    //***************************************************************************
    /// Gets the fill character.
    //***************************************************************************
    ETL_CONSTEXPR typename TString::value_type get_fill() const ETL_NOEXCEPT
    {
      return fill_;
    }

    //***************************************************************************
    /// Sets the left justify flag.
    /// \return A reference to the basic_format_spec.
    //***************************************************************************
    ETL_CONSTEXPR14 basic_format_spec& left() ETL_LVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      left_justified_ = true;
      return *this;
    }

#if ETL_USING_CPP11
    /// @overload
    ETL_CONSTEXPR14 basic_format_spec&& left() ETL_RVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      left_justified_ = true;
      return etl::move(*this);
    }
#endif

    //***************************************************************************
    /// Gets the left justify flag.
    //***************************************************************************
    ETL_CONSTEXPR bool is_left() const ETL_NOEXCEPT
    {
      return left_justified_;
    }

    //***************************************************************************
    /// Sets the right justify flag.
    /// \return A reference to the basic_format_spec.
    //***************************************************************************
    ETL_CONSTEXPR14 basic_format_spec& right() ETL_LVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      left_justified_ = false;
      return *this;
    }

#if ETL_USING_CPP11
    /// @overload
    ETL_CONSTEXPR14 basic_format_spec&& right() ETL_RVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      left_justified_ = false;
      return etl::move(*this);
    }
#endif

    //***************************************************************************
    /// Gets the right justify flag.
    //***************************************************************************
    ETL_CONSTEXPR bool is_right() const ETL_NOEXCEPT
    {
      return !left_justified_;
    }

    //***************************************************************************
    /// Sets the bool alpha flag.
    /// \return A reference to the basic_format_spec.
    //***************************************************************************
    ETL_CONSTEXPR14 basic_format_spec& boolalpha(bool b) ETL_LVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      boolalpha_ = b;
      return *this;
    }

#if ETL_USING_CPP11
    /// @overload
    ETL_CONSTEXPR14 basic_format_spec&& boolalpha(bool b) ETL_RVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      boolalpha_ = b;
      return etl::move(*this);
    }
#endif

    //***************************************************************************
    /// Gets the boolalpha flag.
    //***************************************************************************
    ETL_CONSTEXPR bool is_boolalpha() const ETL_NOEXCEPT
    {
      return boolalpha_;
    }

    //***************************************************************************
    /// Sets the scientific flag.
    /// \return A reference to the basic_format_spec.
    //***************************************************************************
    ETL_CONSTEXPR14 basic_format_spec& scientific(bool b) ETL_LVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      scientific_ = b;
      return *this;
    }

#if ETL_USING_CPP11
    /// @overload
    ETL_CONSTEXPR14 basic_format_spec&& scientific(bool b) ETL_RVALUE_REF_QUALIFIER ETL_NOEXCEPT
    {
      scientific_ = b;
      return etl::move(*this);
    }
#endif

    //***************************************************************************
    /// Gets the scientific flag.
    //***************************************************************************
    ETL_CONSTEXPR bool is_scientific() const ETL_NOEXCEPT
    {
      return scientific_;
    }

    //***************************************************************************
    /// Equality operator.
    //***************************************************************************
    ETL_CONSTEXPR friend bool operator==(const basic_format_spec& lhs, const basic_format_spec& rhs)
    {
      return (lhs.base_ == rhs.base_) && (lhs.width_ == rhs.width_) && (lhs.precision_ == rhs.precision_) && (lhs.upper_case_ == rhs.upper_case_)
             && (lhs.left_justified_ == rhs.left_justified_) && (lhs.boolalpha_ == rhs.boolalpha_) && (lhs.show_base_ == rhs.show_base_)
             && (lhs.fill_ == rhs.fill_) && (lhs.scientific_ == rhs.scientific_);
    }

    //***************************************************************************
    /// Inequality operator.
    //***************************************************************************
    ETL_CONSTEXPR friend bool operator!=(const basic_format_spec& lhs, const basic_format_spec& rhs)
    {
      return !(lhs == rhs);
    }

  private:

    uint_least8_t                base_;
    uint_least8_t                width_;
    uint_least8_t                precision_;
    bool                         upper_case_;
    bool                         left_justified_;
    bool                         boolalpha_;
    bool                         show_base_;
    typename TString::value_type fill_;
    bool                         scientific_;
  };
} // namespace etl

#endif
