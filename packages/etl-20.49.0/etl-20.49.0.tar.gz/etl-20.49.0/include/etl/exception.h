///\file

/******************************************************************************
The MIT License(MIT)

Embedded Template Library.
https://github.com/ETLCPP/etl
https://www.etlcpp.com

Copyright(c) 2014 John Wellbelove

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files(the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and / or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions :

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
******************************************************************************/

#ifndef ETL_EXCEPTION_INCLUDED
#define ETL_EXCEPTION_INCLUDED

#include "platform.h"

#if ETL_USING_STD_EXCEPTION
  #include <exception>
  #define ETL_EXCEPTION_CONSTEXPR
  #define ETL_EXCEPTION_OVERRIDE override
#else
  #define ETL_EXCEPTION_CONSTEXPR ETL_CONSTEXPR
  #define ETL_EXCEPTION_OVERRIDE
#endif

///\defgroup exception exception
/// The base class for all ETL exceptions.
///\ingroup utilities

namespace etl
{
  //***************************************************************************
  ///\ingroup exception
  /// A low overhead exception base class.
  //***************************************************************************
  class exception
#if ETL_USING_STD_EXCEPTION
    : public std::exception
#endif
  {
  public:

    typedef const char* string_type;
    typedef int         numeric_type;

    //*************************************************************************
    /// Constructor.
    //*************************************************************************
#if defined(ETL_VERBOSE_ERRORS)
    ETL_EXCEPTION_CONSTEXPR
    exception(string_type reason_, string_type file_, numeric_type line_)
      : reason_text(reason_)
      , file_text(file_)
      , line(line_)
    {
    }
#elif defined(ETL_MINIMAL_ERRORS)
    ETL_EXCEPTION_CONSTEXPR
    exception(string_type /*reason_*/, string_type /*file_*/, numeric_type /*line_*/) {}
#else
    ETL_EXCEPTION_CONSTEXPR
    exception(string_type reason_, string_type /*file_*/, numeric_type /*line_*/)
      : reason_text(reason_)
    {
    }
#endif

    //***************************************************************************
    /// Gets the reason for the exception.
    /// \return const char* to the reason.
    //***************************************************************************
    ETL_EXCEPTION_CONSTEXPR
    string_type what() const ETL_NOEXCEPT ETL_EXCEPTION_OVERRIDE
    {
#if !defined(ETL_MINIMAL_ERRORS)
      return reason_text;
#else
      return "";
#endif
    }

    //***************************************************************************
    /// Gets the file for the exception.
    /// \return const char* to the file.
    //***************************************************************************
    ETL_EXCEPTION_CONSTEXPR
    string_type file_name() const
    {
#if defined(ETL_VERBOSE_ERRORS)
      return file_text;
#else
      return "";
#endif
    }

    //***************************************************************************
    /// Gets the line for the exception.
    /// \return int as line number.
    //***************************************************************************
    ETL_EXCEPTION_CONSTEXPR
    numeric_type line_number() const
    {
#if defined(ETL_VERBOSE_ERRORS)
      return line;
#else
      return -1;
#endif
    }

  private:

#if !defined(ETL_MINIMAL_ERRORS)
    string_type reason_text; ///< The reason for the exception.
#endif

#if defined(ETL_VERBOSE_ERRORS)
    string_type  file_text; ///< The file for the exception.
    numeric_type line;      ///< The line for the exception.
#endif
  };
} // namespace etl

#endif
