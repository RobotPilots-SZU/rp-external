///\file

/******************************************************************************
The MIT License(MIT)

Embedded Template Library.
https://github.com/ETLCPP/etl
https://www.etlcpp.com

Copyright(c) 2014 John Wellbelove

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files(the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and / or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions :

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
******************************************************************************/

#ifndef ETL_FUNCTIONAL_INCLUDED
#define ETL_FUNCTIONAL_INCLUDED

#include "platform.h"
#include "utility.h"

///\defgroup functional functional
///\ingroup utilities

///\defgroup reference_wrapper reference_wrapper
///\ingroup functional

namespace etl
{
  //***************************************************************************
  /// A definition of reference_wrapper for those that don't have C++11 support.
  ///\ingroup reference
  //***************************************************************************
  template <typename T>
  class reference_wrapper
  {
  public:

    typedef T type;

    ETL_CONSTEXPR20 explicit reference_wrapper(T& t_) ETL_NOEXCEPT
      : t(&t_)
    {
    }

    ETL_CONSTEXPR20 reference_wrapper(const reference_wrapper& rhs) ETL_NOEXCEPT
      : t(rhs.t)
    {
    }

    ETL_CONSTEXPR20 reference_wrapper<T>& operator=(const reference_wrapper& rhs) ETL_NOEXCEPT
    {
      t = rhs.t;
      return *this;
    }

    ETL_CONSTEXPR20 T& get() const ETL_NOEXCEPT
    {
      return *t;
    }

    ETL_CONSTEXPR20 operator T&() const ETL_NOEXCEPT
    {
      return *t;
    }

#if ETL_USING_CPP11
    // implementation without etl::invoke, which would add a circular dependency
    template <typename... TArgs>
    ETL_CONSTEXPR20 auto operator()(TArgs&&... args) const
      noexcept(noexcept(etl::declval<T&>()(etl::declval<TArgs>()...))) -> decltype(etl::declval<T&>()(etl::declval<TArgs>()...))
    {
      return get()(etl::forward<TArgs>(args)...);
    }
#endif

  private:

    T* t;
  };

  //***************************************************************************
  template <typename T>
  reference_wrapper<T> ref(T& t)
  {
    return reference_wrapper<T>(t);
  }

  //***************************************************************************
  template <typename T>
  reference_wrapper<T> ref(reference_wrapper<T> t)
  {
    return reference_wrapper<T>(t.get());
  }

  //***************************************************************************
  template <typename T>
  reference_wrapper<const T> cref(const T& t)
  {
    return reference_wrapper<const T>(t);
  }

  //***************************************************************************
  template <typename T>
  reference_wrapper<const T> cref(reference_wrapper<T> t)
  {
    return reference_wrapper<const T>(t.get());
  }

  //***************************************************************************
  /// unwrap_reference.
  //***************************************************************************
  template <class T>
  struct unwrap_reference
  {
    typedef T type;
  };

  template <typename T>
  struct unwrap_reference<etl::reference_wrapper<T> >
  {
    typedef T& type;
  };

#if ETL_USING_CPP11
  template <typename T>
  using unwrap_reference_t = typename unwrap_reference<T>::type;
#endif

  //***************************************************************************
  /// unwrap_ref_decay.
  //***************************************************************************
  template <typename T>
  struct unwrap_ref_decay : etl::unwrap_reference<typename etl::decay<T>::type>
  {
  };

#if ETL_USING_CPP11
  template <typename T>
  using unwrap_ref_decay_t = typename unwrap_ref_decay<T>::type;
#endif

  //***************************************************************************
  // is_reference_wrapper
  // Detect etl::reference_wrapper<T>
  //***************************************************************************
  template <typename T>
  struct is_reference_wrapper : etl::false_type
  {
  };

  template <typename T>
  struct is_reference_wrapper<etl::reference_wrapper<T> > : etl::true_type
  {
  };

#if ETL_USING_CPP17
  template <typename T>
  inline constexpr bool is_reference_wrapper_v = is_reference_wrapper<T>::value;
#endif

  //***************************************************************************
  /// unary_function
  //***************************************************************************
  template <typename TArgumentType, typename TResultType>
  struct unary_function
  {
    typedef TArgumentType argument_type;
    typedef TResultType   result_type;
  };

  //***************************************************************************
  /// binary_function
  //***************************************************************************
  template <typename TFirstArgumentType, typename TSecondArgumentType, typename TResultType>
  struct binary_function
  {
    typedef TFirstArgumentType  first_argument_type;
    typedef TSecondArgumentType second_argument_type;
    typedef TResultType         result_type;
  };

  //***************************************************************************
  template <typename T = void>
  struct less : public etl::binary_function<T, T, bool>
  {
    typedef T value_type;

    ETL_CONSTEXPR bool operator()(const T& lhs, const T& rhs) const
    {
      return (lhs < rhs);
    }
  };

#if ETL_USING_CPP11
  template <>
  struct less<void> : public etl::binary_function<void, void, bool>
  {
    typedef int is_transparent;

    template <typename T1, typename T2>
    constexpr auto operator()(T1&& lhs, T2&& rhs) const -> decltype(static_cast<T1&&>(lhs) < static_cast<T2&&>(rhs))
    {
      return static_cast<T1&&>(lhs) < static_cast<T2&&>(rhs);
    }
  };
#endif

  //***************************************************************************
  template <typename T = void>
  struct less_equal : public etl::binary_function<T, T, bool>
  {
    typedef T value_type;

    ETL_CONSTEXPR bool operator()(const T& lhs, const T& rhs) const
    {
      return !(rhs < lhs);
    }
  };

#if ETL_USING_CPP11
  template <>
  struct less_equal<void> : public etl::binary_function<void, void, bool>
  {
    typedef int is_transparent;

    template <typename T1, typename T2>
    constexpr auto operator()(T1&& lhs, T2&& rhs) const -> decltype(!(static_cast<T2&&>(rhs) < static_cast<T1&&>(lhs)))
    {
      return !(static_cast<T2&&>(rhs) < static_cast<T1&&>(lhs));
    }
  };
#endif

  //***************************************************************************
  template <typename T = void>
  struct greater : public etl::binary_function<T, T, bool>
  {
    typedef T value_type;

    ETL_CONSTEXPR bool operator()(const T& lhs, const T& rhs) const
    {
      return (rhs < lhs);
    }
  };

#if ETL_USING_CPP11
  template <>
  struct greater<void> : public etl::binary_function<void, void, bool>
  {
    typedef int is_transparent;

    template <typename T1, typename T2>
    constexpr auto operator()(T1&& lhs, T2&& rhs) const -> decltype(static_cast<T2&&>(rhs) < static_cast<T1&&>(lhs))
    {
      return static_cast<T2&&>(rhs) < static_cast<T1&&>(lhs);
    }
  };
#endif

  //***************************************************************************
  template <typename T = void>
  struct greater_equal : public etl::binary_function<T, T, bool>
  {
    typedef T value_type;

    ETL_CONSTEXPR bool operator()(const T& lhs, const T& rhs) const
    {
      return !(lhs < rhs);
    }
  };

#if ETL_USING_CPP11
  template <>
  struct greater_equal<void> : public etl::binary_function<void, void, bool>
  {
    typedef int is_transparent;

    template <typename T1, typename T2>
    constexpr auto operator()(T1&& lhs, T2&& rhs) const -> decltype(!(static_cast<T1&&>(lhs) < static_cast<T2&&>(rhs)))
    {
      return !(static_cast<T1&&>(lhs) < static_cast<T2&&>(rhs));
    }
  };
#endif

  //***************************************************************************
  template <typename T = void>
  struct equal_to : public etl::binary_function<T, T, bool>
  {
    typedef T value_type;

    ETL_CONSTEXPR bool operator()(const T& lhs, const T& rhs) const
    {
      return lhs == rhs;
    }
  };

#if ETL_USING_CPP11
  template <>
  struct equal_to<void> : public etl::binary_function<void, void, bool>
  {
    typedef void value_type;
    typedef int  is_transparent;

    template <typename T1, typename T2>
    constexpr auto operator()(T1&& lhs, T2&& rhs) const -> decltype(static_cast<T1&&>(lhs) == static_cast<T2&&>(rhs))
    {
      return static_cast<T1&&>(lhs) == static_cast<T2&&>(rhs);
    }
  };
#endif

  //***************************************************************************
  template <typename T = void>
  struct not_equal_to : public etl::binary_function<T, T, bool>
  {
    typedef T value_type;

    ETL_CONSTEXPR bool operator()(const T& lhs, const T& rhs) const
    {
      return !(lhs == rhs);
    }
  };

#if ETL_USING_CPP11
  template <>
  struct not_equal_to<void> : public etl::binary_function<void, void, bool>
  {
    typedef int is_transparent;

    template <typename T1, typename T2>
    constexpr auto operator()(T1&& lhs, T2&& rhs) const -> decltype(!(static_cast<T1&&>(lhs) == static_cast<T2&&>(rhs)))
    {
      return !(static_cast<T1&&>(lhs) == static_cast<T2&&>(rhs));
    }
  };
#endif

  //***************************************************************************
  template <typename TFunction>
  class binder1st : public etl::unary_function<typename TFunction::second_argument_type, typename TFunction::result_type>
  {
  protected:

    TFunction                               operation;
    typename TFunction::first_argument_type value;

  public:

    ETL_CONSTEXPR binder1st(const TFunction& f, const typename TFunction::first_argument_type& v)
      : operation(f)
      , value(v)
    {
    }

    ETL_CONSTEXPR typename TFunction::result_type operator()(typename TFunction::second_argument_type& x) const
    {
      return operation(value, x);
    }

    ETL_CONSTEXPR typename TFunction::result_type operator()(const typename TFunction::second_argument_type& x) const
    {
      return operation(value, x);
    }
  };

  template <typename F, typename T>
  ETL_CONSTEXPR binder1st<F> bind1st(const F& f, const T& x)
  {
    return binder1st<F>(f, x);
  }

  //***************************************************************************
  template <typename TFunction >
  class binder2nd : public etl::unary_function<typename TFunction::first_argument_type, typename TFunction::result_type>
  {
  protected:

    TFunction                                operation;
    typename TFunction::second_argument_type value;

  public:

    ETL_CONSTEXPR binder2nd(const TFunction& f, const typename TFunction::second_argument_type& v)
      : operation(f)
      , value(v)
    {
    }

    ETL_CONSTEXPR typename TFunction::result_type operator()(typename TFunction::first_argument_type& x) const
    {
      return operation(x, value);
    }

    ETL_CONSTEXPR typename TFunction::result_type operator()(const typename TFunction::first_argument_type& x) const
    {
      return operation(x, value);
    }
  };

  template <typename F, typename T>
  ETL_CONSTEXPR binder2nd<F> bind2nd(const F& f, const T& x)
  {
    return binder2nd<F>(f, x);
  }

  //***************************************************************************
  template <typename T = void>
  struct plus
  {
    typedef T first_argument_type;
    typedef T second_argument_type;
    typedef T result_type;

    ETL_CONSTEXPR T operator()(const T& lhs, const T& rhs) const
    {
      return lhs + rhs;
    }
  };

  //***************************************************************************
  template <typename T = void>
  struct minus
  {
    typedef T first_argument_type;
    typedef T second_argument_type;
    typedef T result_type;

    ETL_CONSTEXPR T operator()(const T& lhs, const T& rhs) const
    {
      return lhs - rhs;
    }
  };

  //***************************************************************************
  template <typename T = void>
  struct negate
  {
    typedef T argument_type;
    typedef T result_type;

    ETL_CONSTEXPR T operator()(const T& lhs) const
    {
      return -lhs;
    }
  };

  //***************************************************************************
  template <typename T = void>
  struct multiplies
  {
    typedef T first_argument_type;
    typedef T second_argument_type;
    typedef T result_type;

    ETL_CONSTEXPR T operator()(const T& lhs, const T& rhs) const
    {
      return lhs * rhs;
    }
  };

  //***************************************************************************
  template <typename T = void>
  struct divides
  {
    typedef T first_argument_type;
    typedef T second_argument_type;
    typedef T result_type;

    ETL_CONSTEXPR T operator()(const T& lhs, const T& rhs) const
    {
      return lhs / rhs;
    }
  };

  //***************************************************************************
  template <typename T = void>
  struct modulus
  {
    typedef T first_argument_type;
    typedef T second_argument_type;
    typedef T result_type;

    ETL_CONSTEXPR T operator()(const T& lhs, const T& rhs) const
    {
      return lhs % rhs;
    }
  };

  //***************************************************************************
  template <typename T = void>
  struct logical_and
  {
    typedef T first_argument_type;
    typedef T second_argument_type;
    typedef T result_type;

    ETL_CONSTEXPR T operator()(const T& lhs, const T& rhs) const
    {
      return lhs && rhs;
    }
  };

  //***************************************************************************
  template <typename T = void>
  struct logical_or
  {
    typedef T first_argument_type;
    typedef T second_argument_type;
    typedef T result_type;

    ETL_CONSTEXPR T operator()(const T& lhs, const T& rhs) const
    {
      return lhs || rhs;
    }
  };

  //***************************************************************************
  template <typename T = void>
  struct logical_not
  {
    typedef T first_argument_type;
    typedef T second_argument_type;
    typedef T result_type;

    ETL_CONSTEXPR T operator()(const T& lhs) const
    {
      return !lhs;
    }
  };

  //***************************************************************************
  template <typename T = void>
  struct bit_and
  {
    typedef T first_argument_type;
    typedef T second_argument_type;
    typedef T result_type;

    ETL_CONSTEXPR T operator()(const T& lhs, const T& rhs) const
    {
      return lhs & rhs;
    }
  };

  //***************************************************************************
  template <typename T = void>
  struct bit_or
  {
    typedef T first_argument_type;
    typedef T second_argument_type;
    typedef T result_type;

    ETL_CONSTEXPR T operator()(const T& lhs, const T& rhs) const
    {
      return lhs | rhs;
    }
  };

  //***************************************************************************
  template <typename T = void>
  struct bit_xor
  {
    typedef T first_argument_type;
    typedef T second_argument_type;
    typedef T result_type;

    ETL_CONSTEXPR T operator()(const T& lhs, const T& rhs) const
    {
      return lhs ^ rhs;
    }
  };

  //***************************************************************************
  template <typename T = void>
  struct bit_not
  {
    typedef T first_argument_type;
    typedef T second_argument_type;
    typedef T result_type;

    ETL_CONSTEXPR T operator()(const T& lhs) const
    {
      return ~lhs;
    }
  };

#if ETL_USING_CPP11
  namespace private_functional
  {
    //***************************************************************************
    template <typename TReturnType, typename TClassType, typename... TArgs>
    class mem_fn_impl
    {
    public:

      typedef TReturnType (TClassType::*MemberFunctionType)(TArgs...);

      ETL_CONSTEXPR mem_fn_impl(MemberFunctionType member_function_)
        : member_function(member_function_)
      {
      }

      ETL_CONSTEXPR TReturnType operator()(TClassType& instance, TArgs... args) const
      {
        return (instance.*member_function)(etl::forward<TArgs>(args)...);
      }

    private:

      MemberFunctionType member_function;
    };

    //***************************************************************************
    template <typename TReturnType, typename TClassType, typename... TArgs>
    class const_mem_fn_impl
    {
    public:

      typedef TReturnType (TClassType::*MemberFunctionType)(TArgs...) const;

      ETL_CONSTEXPR const_mem_fn_impl(MemberFunctionType member_function_)
        : member_function(member_function_)
      {
      }

      ETL_CONSTEXPR TReturnType operator()(const TClassType& instance, TArgs... args) const
      {
        return (instance.*member_function)(etl::forward<TArgs>(args)...);
      }

    private:

      MemberFunctionType member_function;
    };
  } // namespace private_functional

  //***************************************************************************
  template <typename TReturnType, typename TClassType, typename... TArgs>
  ETL_CONSTEXPR private_functional::mem_fn_impl<TReturnType, TClassType, TArgs...> mem_fn(TReturnType (TClassType::*member_function)(TArgs...))
  {
    return private_functional::mem_fn_impl<TReturnType, TClassType, TArgs...>(member_function);
  }

  //***************************************************************************
  template <typename TReturnType, typename TClassType, typename... TArgs>
  ETL_CONSTEXPR private_functional::const_mem_fn_impl<TReturnType, TClassType, TArgs...> mem_fn(TReturnType (TClassType::*member_function)(TArgs...)
                                                                                              const)
  {
    return private_functional::const_mem_fn_impl<TReturnType, TClassType, TArgs...>(member_function);
  }
#endif

#if ETL_USING_CPP14
  struct identity
  {
    template <class T>
    constexpr T&& operator()(T&& t) const noexcept
    {
      return etl::forward<T>(t);
    }
  };
#endif

#if ETL_USING_CPP17
  namespace ranges
  {
    struct equal_to
    {
      template <typename T, typename U>
      constexpr auto operator()(T&& t, U&& u) const -> decltype(static_cast<T&&>(t) == static_cast<U&&>(u))
      {
        return static_cast<T&&>(t) == static_cast<U&&>(u);
      }
    };

    struct less
    {
      template <typename T, typename U>
      constexpr auto operator()(T&& t, U&& u) const -> decltype(static_cast<T&&>(t) < static_cast<U&&>(u))
      {
        return static_cast<T&&>(t) < static_cast<U&&>(u);
      }
    };
  } // namespace ranges
#endif

} // namespace etl

#endif
